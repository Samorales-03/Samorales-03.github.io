---
tags:
  - toDo
---

- [ ]  [[updateResume|update resume]]
- [ ]  [[writeISS|write iss]]
- [ ]  [[civicTest|civic test]]
