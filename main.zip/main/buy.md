---
tags:
  - toBuy
---

- [ ]  lactose free milk 
- [ ]  lactaid
- [ ]  condoms
- [ ]  vinegar
- [ ]  cheese
- [ ]  b&n notebook
- [ ]  nutella
- [ ]  eggs
- [ ]  paper towels
- [ ]  mop?