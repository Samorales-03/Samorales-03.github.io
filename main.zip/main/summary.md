# events
```dataview
LIST date
FROM "events" 
SORT date
LIMIT 10
```
# daily note
```dataview
CALENDAR file.day
FROM "daily"
```
# quick links
```dataview
list 
FROM (#toBuy or #toWork or #todo) 
WHERE (file.name != "template")
SORT file.mtime DESC
```
