---
tags:
  - toWork
---
today's goals:
- [ ] check-in

today's agenda:
- wake-up