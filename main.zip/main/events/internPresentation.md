date::2024-08-05
## topics to include:
- xtalk automation
- low pass filter design
- verification
## things learned:
- C# scripting, large scale testing
- PCB design, schematic reviews, layout reviews
- how the bu works